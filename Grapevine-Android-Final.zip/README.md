# GRAPEVINE Android

Native Android WebView wrapper for GRAPEVINE.

Fixes in this version:
- Real launcher verification-badge icon (adaptive + legacy icons)
- Version 1.1 / versionCode 2
- Android system status/navigation bars are respected; app content no longer draws behind the navigation bar
- Real Android gallery picker via WebChromeClient
- Service-worker caching for Supabase profile images so previously loaded photos remain visible offline
- Supabase data remains online-backed and local state is retained
