# Grapevine Android V5

This version uses the exact supplied Grapevine blue verification badge image as the Android launcher icon.

- Manifest `android:icon` and `android:roundIcon` point directly to `@drawable/grapevine_badge_launcher`.
- Legacy launcher PNGs are also the exact supplied badge image at every density.
- No Android default launcher foreground/background is used.
- Version 5.0 / versionCode 5.
- Existing WebView, Supabase, gallery picker, offline cache, navigation-bar and home-page improvements from V4 are retained.
