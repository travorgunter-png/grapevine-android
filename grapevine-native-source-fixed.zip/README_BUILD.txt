GRAPEVINE NATIVE SOURCE PACKAGE

This ZIP contains the complete Android source tree required by the GitHub Actions build.
Upload this ZIP to the repository root using the exact filename:
  grapevine-native-source.zip

The GitHub workflow should unzip this package before running Gradle.
