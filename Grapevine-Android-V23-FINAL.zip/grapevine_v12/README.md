# GRAPEVINE Android V21

V21 keeps the existing GRAPEVINE member/admin/gallery features while hardening member authentication and launcher branding.

- Android 8.0+ (API 26)
- Email/password member registration with full name and password confirmation
- No anonymous sign-in for member chat
- Supabase email confirmation supported
- Member chat sign-in and admin replies
- Gallery image/video/audio upload with a required storage bucket
- Member download requests with admin approve/reject workflow
- Admin Messages & Replies section
- Offline media/photo caching already included
- Explicit Grapevine legacy + Android adaptive launcher icon


Before distributing V21, run app/src/main/assets/SUPABASE_SETUP.sql in the Supabase SQL Editor. Add the exact redirect URL `grapevine://auth-callback` to Supabase Authentication URL Configuration > Additional Redirect URLs.
