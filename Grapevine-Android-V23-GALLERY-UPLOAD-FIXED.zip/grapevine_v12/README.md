# GRAPEVINE Android V23

V21 keeps the existing GRAPEVINE member/admin/gallery features while hardening member authentication and launcher branding.

- Android 8.0+ (API 26)
- Email/password member registration with full name and password confirmation
- No anonymous sign-in for member chat
- Supabase email confirmation supported
- Member chat sign-in and admin replies
- Gallery image/video/audio upload with resumable uploads for media larger than 6 MB
- Member download requests with admin approve/reject workflow
- Admin Messages & Replies section
- Offline media/photo caching already included
- Explicit Grapevine legacy + Android adaptive launcher icon


Before distributing V21, run app/src/main/assets/SUPABASE_SETUP.sql in the Supabase SQL Editor. Add the exact redirect URL `grapevine://auth-callback` to Supabase Authentication URL Configuration > Additional Redirect URLs.


## V23 gallery upload fix
The Android WebView now uses Supabase resumable/TUS uploads for files larger than 6 MB, including MP4 videos such as 12.9 MB files. The updated SQL also sets the `gallery-media` bucket limit to 50 MB. Run the updated `app/src/main/assets/SUPABASE_SETUP.sql` once in the Supabase SQL Editor before testing the new APK.
