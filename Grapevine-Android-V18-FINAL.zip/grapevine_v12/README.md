# GRAPEVINE Android V18

V18 keeps the existing GRAPEVINE member/admin/gallery features while hardening member authentication and launcher branding.

- Android 8.0+ (API 26)
- Email/password member registration with full name and password confirmation
- No anonymous sign-in for member chat
- Supabase email confirmation supported
- Member chat sign-in and admin replies
- Gallery image/video/audio upload, approval and download
- Offline media/photo caching already included
- Explicit Grapevine legacy + Android adaptive launcher icon
