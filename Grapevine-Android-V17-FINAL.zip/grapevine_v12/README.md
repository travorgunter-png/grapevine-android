GRAPEVINE Android V17 — member chat, Android 8+, gallery media approval/download

This build preserves the existing Grapevine design and previous profile-photo/offline fixes, and adds only the requested fixes:
- Member Supabase sign-in validation and clearer session errors for chat.
- Android minimum supported version is Android 8.0 (API 26).
- Gallery upload accepts images, video and audio, including multiple files at once.
- Gallery uploads can be made while offline and are queued on the device for submission when connectivity returns.
- Member gallery uploads remain pending until an administrator approves them.
- Approved gallery media has a Download action; the Android wrapper uses the native Android DownloadManager.
- Admin Dashboard > Chat now clearly provides a member-message reply area and refresh control.
- Existing member photos, verification badge, launcher icon, projects, skills and other screens are preserved.

Run the updated SUPABASE_SETUP.sql once on the existing Grapevine Supabase project before distributing this APK.
