GRAPEVINE Android V10

Fixes:
- Uses the supplied GRAPEVINE emblem as the Android launcher icon.
- Uses the same supplied GRAPEVINE emblem as the in-app verification badge for members marked verified by an administrator.
- Keeps the V9 startup/WebView fixes.
- versionCode 10 / versionName 10.0.

Important: a member's badge appears only when that member is marked verified in the online admin dashboard. The app does not falsely mark members as verified by default.
