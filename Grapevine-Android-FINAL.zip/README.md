# Grapevine Android — clean build package

This is the complete native Android WebView wrapper for Grapevine V9.

Key fixes:
- Real Android image picker through WebChromeClient.onShowFileChooser().
- No AppCompat dependency, avoiding the previous Kotlin duplicate-class conflict.
- Android SDK 35 / Java 17 compatible build configuration.
- Grapevine web app and Supabase configuration are bundled in app/src/main/assets.

The APK is produced by the GitHub Actions workflow supplied separately. This source package itself is not an APK.
