# Grapevine Android V8 — Badge Icon + Startup Fix

- Uses the supplied GRAPEVINE badge artwork as the launcher icon.
- Version 8.0 / versionCode 8.
- Loads the bundled web app directly from `android_asset` for maximum Android/WebView compatibility.
- Removed the AndroidX WebKit runtime dependency that could prevent the activity from starting on some devices.
- Gallery/file picker support is retained.
