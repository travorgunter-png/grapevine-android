GRAPEVINE Android V9 — startup reliability fix

This build keeps the supplied Grapevine badge as the launcher icon.
The Android wrapper now uses a secure local HTTPS asset origin instead of file://, and the web app no longer relies on structuredClone during startup.

Build with Android Studio/Gradle and install version 9.0 after uninstalling the older Grapevine build.
