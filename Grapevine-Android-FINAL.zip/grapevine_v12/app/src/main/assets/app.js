/* GRAPEVINE — Supabase-connected edition
   Security model: Supabase Auth + public.admins + Row Level Security.
   Never put a Supabase service-role/secret key in this app.
*/
const DEFAULT={settings:{name:'GRAPEVINE',motto:'Code Today. Build Tomorrow. Inspire Forever.',description:'A software engineering group built around collaboration, innovation and practical technology.',email:'grapevine@example.com',phone:'+256 700 000 000',location:'Uganda'},members:Array.from({length:11},(_,i)=>({id:'m'+(i+1),name:'Member '+(i+1),role:'Software Engineering Team',bio:'GRAPEVINE member profile. Update this profile from the admin dashboard.',skills:['Programming','Teamwork'],verified:i===0,photo:''})),projects:[{id:'p1',title:'Project One',description:'Project description and results.',tags:['Web','Software']}],skills:[{id:'s1',title:'Web Development',description:'HTML, CSS, JavaScript and responsive interfaces.'}],gallery:[{id:'g1',title:'Our identity',image:'assets/grapevine-logo.jpg'}]};
const CFG_KEY='gv_supabase_config', SESSION_KEY='gv_supabase_session';
const BUILTIN_SUPABASE={url:'https://bcinhmoyyjbkdcpkrztr.supabase.co',key:'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImJjaW5obW95eWpia2RjcGtyenRyIiwicm9sZSI6ImFub24iLCJpYXQiOjE3OTExMzAxNDksImV4cCI6MjEwNjcwNjE0OX0.n_GlM4exGN2eceSSxXpqhGTjckkt_sUhXGR22PdRo58'};
let cfg=JSON.parse(localStorage.getItem(CFG_KEY)||'null')||BUILTIN_SUPABASE;
let session=JSON.parse(localStorage.getItem(SESSION_KEY)||'null');
let state=load(); let route='home'; let adminSession=false; let chatTimer=null;
function cloneDefault(){return JSON.parse(JSON.stringify(DEFAULT))}
function load(){try{const raw=localStorage.getItem('gv_state');return raw?JSON.parse(raw):cloneDefault()}catch{return cloneDefault()}}
function save(){localStorage.setItem('gv_state',JSON.stringify(state))}
function online(){return navigator.onLine}
function configured(){return !!(cfg.url&&cfg.key)}
function esc(s=''){return String(s).replace(/[&<>\"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','\"':'&quot;',"'":'&#39;'}[c]))}

// Persistent profile-photo cache. Profile photos are remote Supabase images, so the
// service worker cannot reliably cache them because they are cross-origin. We cache
// the image bytes in IndexedDB instead, keyed by member id, and reuse them offline.
const PHOTO_DB='grapevine-profile-photos-v2';
let photoDbPromise=null;
function photoDB(){
  if(photoDbPromise)return photoDbPromise;
  photoDbPromise=new Promise((resolve,reject)=>{
    if(!('indexedDB' in window)){reject(new Error('IndexedDB unavailable'));return}
    const req=indexedDB.open(PHOTO_DB,1);
    req.onupgradeneeded=()=>{if(!req.result.objectStoreNames.contains('photos'))req.result.createObjectStore('photos',{keyPath:'id'})};
    req.onsuccess=()=>resolve(req.result);
    req.onerror=()=>reject(req.error||new Error('Could not open photo cache'));
  });
  return photoDbPromise;
}
async function photoGet(id){
  try{const db=await photoDB();return await new Promise((resolve,reject)=>{const r=db.transaction('photos','readonly').objectStore('photos').get(String(id));r.onsuccess=()=>resolve(r.result||null);r.onerror=()=>reject(r.error)})}catch{return null}
}
async function photoPut(id,url,blob){
  try{const db=await photoDB();await new Promise((resolve,reject)=>{const r=db.transaction('photos','readwrite').objectStore('photos').put({id:String(id),url:url||'',blob,savedAt:Date.now()});r.onsuccess=resolve;r.onerror=()=>reject(r.error)});return true}catch{return false}
}
function setPhotoFromBlob(img,blob){
  try{if(img._objectUrl)URL.revokeObjectURL(img._objectUrl);img._objectUrl=URL.createObjectURL(blob);img.src=img._objectUrl}catch{}
}
async function hydrateProfilePhotos(){
  const imgs=[...document.querySelectorAll('img[data-profile-id]')];
  await Promise.all(imgs.map(async img=>{
    const id=img.dataset.profileId;
    const url=img.dataset.photoUrl||'';
    const cached=await photoGet(id);

    // Offline: always prefer the last successfully saved photo.
    if(!online()){
      if(cached?.blob)setPhotoFromBlob(img,cached.blob);
      return;
    }

    // Online: keep the cached photo visible immediately while refreshing it.
    if(cached?.blob)setPhotoFromBlob(img,cached.blob);
    if(!url)return;

    // Do not repeatedly download the same image on every render.
    if(cached?.blob && cached.url===url)return;

    try{
      const r=await fetch(url,{mode:'cors',cache:'no-store'});
      if(!r.ok)throw new Error('Photo request failed');
      const blob=await r.blob();
      if(!blob.type.startsWith('image/'))throw new Error('Not an image');
      await photoPut(id,url,blob);
      setPhotoFromBlob(img,blob);
    }catch{
      // If Supabase is temporarily unreachable, leave the cached image in place.
      if(!cached?.blob && url)img.src=url;
    }
  }));
}
function verifiedBadge(){return '<span class="verification-badge" role="img" title="Verified member" aria-label="Verified member"><svg viewBox="0 0 100 100" focusable="false" aria-hidden="true"><path class="seal" d="M50 2 L57 9 L67 7 L72 16 L82 18 L82 29 L91 35 L87 45 L94 53 L87 61 L91 71 L82 77 L82 88 L72 90 L67 99 L57 97 L50 104 L43 97 L33 99 L28 90 L18 88 L18 77 L9 71 L13 61 L6 53 L13 45 L9 35 L18 29 L18 18 L28 16 L33 7 L43 9 Z"/><path class="check" d="M29 51 L43 65 L72 35"/></svg></span>'}
function headers(extra={}){return {'apikey':cfg.key,'Content-Type':'application/json',...(session?.access_token?{Authorization:'Bearer '+session.access_token}:{}),...extra}}
async function authFetch(path,opts={},retry=true){if(!configured())throw Error('Supabase is not configured');let r=await fetch(cfg.url.replace(/\/$/,'')+path,{...opts,headers:headers(opts.headers||{})});if(r.status===401&&retry&&session?.refresh_token){try{await refreshSession();return authFetch(path,opts,false)}catch{}}if(!r.ok){let t=await r.text();throw Error(t||('HTTP '+r.status))}return r.status===204?null:r.json()}
async function refreshSession(){if(!session?.refresh_token)throw Error('Session expired');const r=await fetch(cfg.url.replace(/\/$/,'')+'/auth/v1/token?grant_type=refresh_token',{method:'POST',headers:headers(),body:JSON.stringify({refresh_token:session.refresh_token})});if(!r.ok)throw Error('Session expired');session=await r.json();localStorage.setItem(SESSION_KEY,JSON.stringify(session));return session}
async function login(email,password){const r=await fetch(cfg.url.replace(/\/$/,'')+'/auth/v1/token?grant_type=password',{method:'POST',headers:headers(),body:JSON.stringify({email,password})});if(!r.ok)throw Error((await r.json().catch(()=>({}))).error_description||'Invalid email or password');session=await r.json();localStorage.setItem(SESSION_KEY,JSON.stringify(session));return session}
async function signup(email,password){const r=await fetch(cfg.url.replace(/\/$/,'')+'/auth/v1/signup',{method:'POST',headers:headers(),body:JSON.stringify({email,password})});const x=await r.json().catch(()=>({}));if(!r.ok)throw Error(x.msg||x.error_description||'Could not create account');if(x.access_token){session=x;localStorage.setItem(SESSION_KEY,JSON.stringify(session))}return x}
async function signout(){session=null;adminSession=false;localStorage.removeItem(SESSION_KEY);route='admin';render()}
async function isAdmin(){if(!session?.user?.id)return false;const rows=await authFetch('/rest/v1/admins?select=user_id&user_id=eq.'+encodeURIComponent(session.user.id));return Array.isArray(rows)&&rows.length>0}
async function dbGet(table,query=''){return authFetch('/rest/v1/'+table+'?'+query,{headers:{Prefer:'return=representation'}})}
async function dbInsert(table,row){return authFetch('/rest/v1/'+table,{method:'POST',headers:{Prefer:'return=representation'},body:JSON.stringify(row)})}
async function dbPatch(table,filter,row){return authFetch('/rest/v1/'+table+'?'+filter,{method:'PATCH',headers:{Prefer:'return=representation'},body:JSON.stringify(row)})}
async function dbDelete(table,filter){return authFetch('/rest/v1/'+table+'?'+filter,{method:'DELETE',headers:{Prefer:'return=representation'}})}
async function loadRemote(){if(!configured()||!online())return false;try{
 const profiles=await dbGet('profiles','select=*&order=created_at.asc');
 const settings=await dbGet('site_settings','select=*&id=eq.1');
 const content=await dbGet('content_items','select=*&order=created_at.asc');
 if(profiles)state.members=profiles.map(p=>({id:p.id,name:p.name,role:p.role||'Member',bio:p.bio||'',skills:typeof p.skills==='string'?p.skills.split(',').map(x=>x.trim()).filter(Boolean):(p.skills||[]),verified:(p.verified===true||p.verified===1||p.verified==='true'),photo:p.photo_url||''}));
 if(settings?.[0]?.settings)state.settings={...state.settings,...settings[0].settings};
 if(content){state.projects=content.filter(x=>x.kind==='project').map(x=>({id:x.id,title:x.title,description:x.description||'',tags:x.tags||[]}));state.skills=content.filter(x=>x.kind==='skill').map(x=>({id:x.id,title:x.title,description:x.description||''}));state.gallery=content.filter(x=>x.kind==='gallery').map(x=>({id:x.id,title:x.title,image:x.image_url||''}));}
 save();return true;
 }catch(e){return false}}
async function sync(){if(await loadRemote())render()}
window.addEventListener('online',()=>{sync();toast('Back online')});window.addEventListener('offline',()=>toast('Offline: showing cached data'));
if('serviceWorker' in navigator)navigator.serviceWorker.register('sw.js').catch(()=>{});
function render(){document.getElementById('app').innerHTML=`<div class="shell"><header class="top"><div class="brand"><img src="assets/grapevine-logo.jpg"><div><b>${esc(state.settings.name)}</b><small>Software Engineering Group</small></div></div><span class="status ${online()?'online':'offline'}">${online()?'ONLINE':'OFFLINE'}</span></header><main class="content">${view()}</main>${bottom()}</div>`;hydrateProfilePhotos().catch(()=>{})}
function bottom(){return `<nav class="bottom">${[['home','⌂','Home'],['members','♙','Members'],['projects','▣','Projects'],['gallery','▧','Gallery'],['chat','💬','Chat'],['admin','⚙','Admin']].map(x=>`<button class="${route===x[0]?'active':''}" onclick="go('${x[0]}')"><span>${x[1]}</span>${x[2]}</button>`).join('')}</nav>`}
function view(){if(route==='members')return members();if(route==='projects')return projects();if(route==='gallery')return gallery();if(route==='chat')return chat();if(route==='admin'||route.startsWith('admin-'))return admin();return home()}
function home(){return `<section class="hero"><img src="assets/grapevine-logo.jpg"><div class="eyebrow">SOFTWARE ENGINEERING • CREATIVITY • TEAMWORK</div><h1>We Code. We Build. We Inspire.</h1><p>${esc(state.settings.description)}</p><p><b>${esc(state.settings.motto)}</b></p><div class="actions"><button class="btn gold" onclick="go('members')">Meet Members</button><button class="btn light" onclick="go('projects')">Explore Projects</button></div></section><h2>GRAPEVINE at a glance</h2><div class="grid"><div class="card"><div class="stat">${state.members.length}</div><p>Members</p></div><div class="card"><div class="stat">${state.projects.length}</div><p>Projects</p></div><div class="card"><div class="stat">${state.skills.length}</div><p>Skills</p></div><div class="card"><div class="stat">${state.gallery.length}</div><p>Gallery items</p></div></div><section class="home-overview"><div class="card"><div class="eyebrow">WELCOME TO GRAPEVINE</div><h2 class="overview-title">A place to connect, learn, build and grow.</h2><p class="overview-copy">Discover our members, explore projects, share skills and stay connected with the GRAPEVINE community.</p><div class="home-quick"><button class="btn gold" onclick="go('members')">Members</button><button class="btn light" onclick="go('projects')">Projects</button><button class="btn light" onclick="go('gallery')">Gallery</button></div></div><div class="home-cards"><article class="home-feature"><div class="feature-icon">👥</div><h3>Community</h3><p>Meet people, see member profiles and discover what the team can do.</p></article><article class="home-feature"><div class="feature-icon">🛠️</div><h3>Projects</h3><p>Explore practical ideas, software projects and collaborative work.</p></article><article class="home-feature"><div class="feature-icon">📚</div><h3>Skills</h3><p>Learn from shared experience and find skills across the community.</p></article><article class="home-feature"><div class="feature-icon">✓</div><h3>Trusted profiles</h3><p>Administrators can give the official blue check badge to verified members.</p></article></div></section><section class="home-info"><div class="info-head"><div><div class="eyebrow">ABOUT US</div><h2>More about GRAPEVINE</h2></div><span class="tag verified">Community</span></div><div class="welcome-note"><h3>A connected engineering community</h3><p>GRAPEVINE brings software engineers and technology enthusiasts together to learn, build practical solutions, share skills and grow as a team.</p></div><div class="info-grid"><article class="info-card"><div class="info-icon">💻</div><h3>Build</h3><p>Turn ideas into useful software, projects and digital solutions.</p></article><article class="info-card"><div class="info-icon">🧠</div><h3>Learn</h3><p>Share knowledge, skills and experience across the team.</p></article><article class="info-card"><div class="info-icon">🤝</div><h3>Connect</h3><p>Meet members, discover their skills and collaborate on projects.</p></article><article class="info-card"><div class="info-icon">🚀</div><h3>Grow</h3><p>Create opportunities for teamwork, creativity and professional growth.</p></article></div><div class="home-strip"><div class="card"><strong>Members</strong><span>${online()?'Live data synced with Supabase':'Using saved offline data'}</span></div><div class="card"><strong>Verification</strong><span>Admin-verified members display the official badge.</span></div></div></section><div class="card" style="margin-top:14px"><div class="eyebrow">CONTACT</div><h3>${esc(state.settings.email)}</h3><p>${esc(state.settings.phone)} • ${esc(state.settings.location)}</p></div>`}
function members(){return `<div class="admin-head"><div><div class="eyebrow">THE TEAM</div><h2>Members</h2></div></div><div class="search"><input placeholder="Search members" oninput="filterMembers(this.value)"></div><div id="memberList">${memberCards(state.members)}</div>`}
function memberCards(arr){return arr.map(m=>`<article class="card member"><img class="photo profile-photo" data-profile-id="${esc(m.id)}" data-photo-url="${esc(m.photo||'')}" src="assets/grapevine-logo.jpg" onerror="this.src='assets/grapevine-logo.jpg'"><div class="member-main"><div class="member-name"><h3 style="margin:0">${esc(m.name)}</h3>${m.verified?verifiedBadge():''}</div><div class="small">${esc(m.role)}</div><p>${esc(m.bio)}</p><div>${(m.skills||[]).map(s=>`<span class="tag">${esc(s)}</span>`).join('')}</div></div></article>`).join('')||'<div class="empty">No members found.</div>'}
function filterMembers(q){const x=(q||'').toLowerCase();document.getElementById('memberList').innerHTML=memberCards(state.members.filter(m=>(m.name+' '+m.role).toLowerCase().includes(x)));hydrateProfilePhotos().catch(()=>{})}
function projects(){return `<div class="eyebrow">OUR WORK</div><h2>Projects</h2><div class="grid">${state.projects.map(p=>`<article class="card"><div class="eyebrow">PROJECT</div><h3>${esc(p.title)}</h3><p>${esc(p.description)}</p>${(p.tags||[]).map(t=>`<span class="tag">${esc(t)}</span>`).join('')}</article>`).join('')}</div>`}
function gallery(){return `<div class="eyebrow">MEMORIES</div><h2>Gallery</h2><div class="grid">${state.gallery.map(g=>`<article class="card"><img style="width:100%;aspect-ratio:1.2;object-fit:cover;border-radius:12px" src="${esc(g.image||'assets/grapevine-logo.jpg')}"><h3>${esc(g.title)}</h3></article>`).join('')}</div>`}
function admin(){if(!configured())return configView();if(!session)return adminLogin();if(!adminSession)return `<section class="card"><div class="eyebrow">SECURE ADMIN</div><h2>Checking administrator access…</h2><p>Your Supabase account is being checked against the <b>admins</b> table. A normal member account cannot enter the control centre.</p></section>`;return adminPanel()}
function configView(){return `<section class="card"><div class="eyebrow">FIRST-TIME SETUP</div><h2>Connect GRAPEVINE</h2><p>Enter your Supabase <b>Project URL</b> and <b>Publishable/anon key</b>. These are client-side values. <b>Never enter a service-role or secret key.</b></p><div class="field"><label>Supabase Project URL</label><input id="cfg-url" placeholder="https://your-project.supabase.co"></div><div class="field"><label>Publishable / anon key</label><textarea id="cfg-key" rows="4" placeholder="eyJ..."></textarea></div><button class="btn primary" onclick="saveConfig()">Connect Supabase</button><div class="notice">After connecting, the app will use Supabase Auth and database permissions instead of a device PIN.</div></section>`}
function adminLogin(){return `<section class="card"><div class="eyebrow">SECURE ADMIN LOGIN</div><h2>Administrator sign in</h2><p>Use the email and password of the account that was added to the Supabase <b>admins</b> table. There is no admin PIN stored in this APK.</p><div class="field"><label>Email</label><input id="login-email" type="email" autocomplete="username"></div><div class="field"><label>Password</label><input id="login-pass" type="password" autocomplete="current-password"></div><button class="btn primary" onclick="doAdminLogin()">Sign in securely</button><button class="btn light" onclick="go('home')">Cancel</button></section>`}
function adminPanel(){return `<div class="admin-head"><div><div class="eyebrow">ONLINE CONTROL CENTRE</div><h2>Admin Dashboard</h2><div class="small">${esc(session?.user?.email||'Administrator')}</div></div><button class="btn light" onclick="signout()">Sign out</button></div><div class="admin-tabs">${['members','projects','skills','gallery','settings','chat'].map(t=>`<button class="btn ${route==='admin-'+t?'primary':'light'}" onclick="adminSection('${t}')">${t}</button>`).join('')}</div>${route==='admin-members'?adminMembers():route==='admin-projects'?adminCollection('projects','Project'):route==='admin-skills'?adminCollection('skills','Skill'):route==='admin-gallery'?adminCollection('gallery','Gallery item'):route==='admin-chat'?adminChat():adminSettings()}`}
function adminMembers(){const total=state.members.length,verified=state.members.filter(m=>m.verified).length;return `<section class="member-control"><div class="control-hero"><div><div class="eyebrow">ADMIN • MEMBER MANAGEMENT</div><h2>Member Control Centre</h2><p>Online changes apply to the shared GRAPEVINE database for every user.</p></div><button class="btn gold big" onclick="editMember()">＋ Add Member</button></div><div class="member-stats"><div class="stat-card"><strong>${total}</strong><span>Total Members</span></div><div class="stat-card"><strong>${verified}</strong><span>Verified</span></div><div class="stat-card"><strong>${total-verified}</strong><span>Unverified</span></div></div><div class="member-toolbar"><input id="memberSearchAdmin" placeholder="Search by member name or role" oninput="filterAdminMembers(this.value)"></div><div id="adminMemberList">${adminMemberRows(state.members)}</div></section>`}
function adminMemberRows(arr){return arr.map(m=>`<article class="admin-member-card"><div class="admin-member-info"><img class="admin-avatar profile-photo" data-profile-id="${esc(m.id)}" data-photo-url="${esc(m.photo||'')}" src="assets/grapevine-logo.jpg" onerror="this.src='assets/grapevine-logo.jpg'"><div><div class="admin-member-name">${esc(m.name||'Unnamed Member')} ${m.verified?verifiedBadge():'<span class="unverified">Not verified</span>'}</div><div class="small">${esc(m.role||'No role assigned')}</div></div></div><div class="admin-member-actions"><button class="btn ${m.verified?'light':'gold'}" onclick="verifyMember('${m.id}',${!m.verified})">${m.verified?'Remove Badge':'Give Verification Badge'}</button><button class="btn light" onclick="editMember('${m.id}')">Edit Member</button><button class="btn danger" onclick="removeMember('${m.id}')">Remove Member</button></div></article>`).join('')||'<div class="empty">No members found.</div>'}
function filterAdminMembers(q){const x=(q||'').toLowerCase(),el=document.getElementById('adminMemberList');if(el){el.innerHTML=adminMemberRows(state.members.filter(m=>(m.name+' '+m.role).toLowerCase().includes(x)));hydrateProfilePhotos().catch(()=>{})}}
function adminCollection(key,label){return `<div class="actions"><button class="btn gold" onclick="editCollection('${key}')">+ Add ${label}</button></div><div>${state[key].map(x=>`<div class="row"><div><b>${esc(x.title)}</b><div class="small">${esc(x.description||x.image||'')}</div></div><div class="actions"><button class="btn light" onclick="editCollection('${key}','${x.id}')">Edit</button><button class="btn danger" onclick="removeItem('${key}','${x.id}')">Remove</button></div></div>`).join('')}</div>`}
function adminSettings(){const s=state.settings;return `<div class="card"><h3>App-wide settings</h3>${['name','motto','description','email','phone','location'].map(k=>`<div class="field"><label>${k}</label><input id="set-${k}" value="${esc(s[k]||'')}"></div>`).join('')}<button class="btn primary" onclick="saveSettings()">Save changes online</button><button class="btn light" onclick="showConfigChange()">Change Supabase connection</button></div>`}
function chat(){if(!configured())return `<section class="card"><h2>Chat</h2><p>Connect Supabase first to use secure online chat.</p></section>`;if(!session)return chatLogin();return `<section class="card"><div class="eyebrow">GRAPEVINE CHAT</div><h2>Chat with the team</h2><p>Send a message to the GRAPEVINE administrators.</p><div id="chatMessages" class="chat-box"><div class="empty">Loading messages…</div></div><div class="field"><textarea id="chatInput" rows="3" placeholder="Write your message…"></textarea></div><button class="btn primary" onclick="sendChat(false)">Send message</button><button class="btn light" onclick="signout()">Sign out</button></section>`}
function chatLogin(){return `<section class="card"><div class="eyebrow">MEMBER CHAT</div><h2>Sign in to chat</h2><p>Chat uses Supabase Auth. If your account is new and email confirmation is enabled, confirm the email before signing in.</p><div class="field"><label>Email</label><input id="chat-email" type="email"></div><div class="field"><label>Password</label><input id="chat-pass" type="password"></div><button class="btn primary" onclick="doChatLogin()">Sign in</button><button class="btn light" onclick="doChatSignup()">Create member account</button></section>`}
async function loadChat(){if(!session)return;try{const rows=await dbGet('chat_messages','select=id,sender_id,sender_name,message,is_admin,created_at&order=created_at.asc&limit=100');const el=document.getElementById('chatMessages');if(el)el.innerHTML=rows.map(m=>`<div class="chat-msg ${m.sender_id===session.user.id?'mine':''}"><b>${esc(m.sender_name||'User')}${m.is_admin?' • Admin':''}</b><p>${esc(m.message)}</p><small>${new Date(m.created_at).toLocaleString()}</small></div>`).join('')||'<div class="empty">No messages yet.</div>'}catch(e){const el=document.getElementById('chatMessages');if(el)el.innerHTML='<div class="notice">Chat could not be loaded. Check your connection.</div>'}}
function adminChat(){return `<section class="card"><div class="eyebrow">ADMIN • CHAT</div><h2>Member messages</h2><div id="chatMessages" class="chat-box"><div class="empty">Loading messages…</div></div><div class="field"><input id="chatReplyName" value="GRAPEVINE Admin" placeholder="Admin display name"></div><div class="field"><textarea id="chatInput" rows="3" placeholder="Reply to the member conversation…"></textarea></div><button class="btn primary" onclick="sendChat(true)">Send admin reply</button></section>`}
async function sendChat(isAdmin){const input=document.getElementById('chatInput');const message=input?.value.trim();if(!message)return toast('Write a message first');try{await dbInsert('chat_messages',{sender_id:session.user.id,sender_name:isAdmin?(document.getElementById('chatReplyName')?.value.trim()||'GRAPEVINE Admin'):(session.user.email||'Member'),message,is_admin:isAdmin});input.value='';await loadChat();toast('Message sent')}catch(e){toast('Message failed: '+friendly(e))}}
async function doChatLogin(){try{await login(document.getElementById('chat-email').value.trim(),document.getElementById('chat-pass').value);await loadChat();render();loadChat()}catch(e){toast(friendly(e))}}
async function doChatSignup(){try{const x=await signup(document.getElementById('chat-email').value.trim(),document.getElementById('chat-pass').value);toast(x.access_token?'Account created':'Account created. Check your email, then sign in.');if(!x.access_token)render();}catch(e){toast(friendly(e))}}
async function doAdminLogin(){try{await login(document.getElementById('login-email').value.trim(),document.getElementById('login-pass').value);if(!(await isAdmin())){await signout();throw Error('This account is not an authorized GRAPEVINE administrator.')}adminSession=true;route='admin-members';await sync();render();toast('Secure admin access granted')}catch(e){toast(friendly(e))}}
function friendly(e){try{const x=JSON.parse(e.message);return x.message||x.hint||e.message}catch{return e.message||'Something went wrong'}}
async function saveConfig(){const url=document.getElementById('cfg-url').value.trim();const key=document.getElementById('cfg-key').value.trim();await saveConfigValues(url,key)}
function showConfigChange(){document.body.insertAdjacentHTML('beforeend',`<div class="modal" id="modal"><div class="sheet"><h2>Supabase connection</h2><p>Use only the Project URL and publishable/anon key. Never use a service-role/secret key.</p><div class="field"><label>Project URL</label><input id="cfg-url" value="${esc(cfg.url)}"></div><div class="field"><label>Publishable / anon key</label><textarea id="cfg-key" rows="4">${esc(cfg.key)}</textarea></div><div class="actions"><button class="btn light" onclick="document.getElementById('modal').remove()">Cancel</button><button class="btn primary" onclick="saveConfigFromModal()">Save</button></div></div></div>`)}
async function saveConfigFromModal(){const url=document.getElementById('cfg-url').value.trim();const key=document.getElementById('cfg-key').value.trim();document.getElementById('modal').remove();await saveConfigValues(url,key)}
async function saveConfigValues(url,key){url=url.replace(/\/$/,'');if(!/^https:\/\/[^ ]+$/i.test(url)||!key)return toast('Enter a valid Supabase Project URL and publishable/anon key');cfg={url,key};localStorage.setItem(CFG_KEY,JSON.stringify(cfg));toast('Supabase connection saved');await sync();render()}
async function adminSection(k){if(!adminSession){route='admin';render();return}route='admin-'+k;render();if(k==='chat')loadChat()}
async function verifyMember(id,v){try{if(!session?.access_token||!adminSession)throw Error('Admin session required');const rows=await dbPatch('profiles','id=eq.'+encodeURIComponent(id),{verified:v,verified_at:v?new Date().toISOString():null});if(!Array.isArray(rows)||rows.length===0)throw Error('The member was not changed. Check that this account is an administrator.');const m=state.members.find(x=>String(x.id)===String(id));if(m){m.verified=v;save()}render();toast(v?'✓ Verification badge granted online':'Verification badge removed online')}catch(e){toast(friendly(e))}}
async function removeMember(id){const m=state.members.find(x=>String(x.id)===String(id));if(!m||!confirm('Remove '+(m.name||'this member')+' from GRAPEVINE?'))return;try{await dbDelete('profiles','id=eq.'+encodeURIComponent(id));await sync();render();toast('Member removed online')}catch(e){toast(friendly(e))}}
async function editMember(id){const m=id?state.members.find(x=>String(x.id)===String(id)):null;const item=m?{...m}:{id:null,name:'',role:'Software Engineering Team',bio:'',skills:[],verified:false,photo:''};openMemberForm(id?'Edit Member':'Add New Member',item,async x=>{try{const row={name:x.name,role:x.role,bio:x.bio,skills:(x.skills||[]).join(', '),photo_url:x.photo||null,verified:!!x.verified,verified_at:x.verified?new Date().toISOString():null};if(id)await dbPatch('profiles','id=eq.'+encodeURIComponent(id),row);else await dbInsert('profiles',row);await sync();render();toast('Member saved online')}catch(e){toast(friendly(e))}})}
function openMemberForm(title,item,done){document.body.insertAdjacentHTML('beforeend',`<div class="modal" id="modal"><div class="sheet"><h2>${title}</h2><div class="field"><label>Name</label><input id="f-name" value="${esc(item.name)}"></div><div class="field"><label>Role</label><input id="f-role" value="${esc(item.role)}"></div><div class="field"><label>Bio</label><textarea id="f-bio">${esc(item.bio)}</textarea></div><div class="field"><label>Skills (comma separated)</label><input id="f-skills" value="${esc((item.skills||[]).join(', '))}"></div><div class="field"><label>Profile photo</label><div class="photo-picker"><img id="photo-preview" class="form-photo-preview" src="${esc(item.photo||'assets/grapevine-logo.jpg')}" onerror="this.src='assets/grapevine-logo.jpg'"><div><label class="photo-file-label" for="f-photo-file"><span class="photo-file-icon">📷</span><span>Choose / Upload Photo</span></label><input id="f-photo-file" class="native-photo-input" type="file" accept="image/*" aria-label="Choose member photo" onchange="previewMemberPhoto(this)"><div class="photo-help">Tap “Choose / Upload Photo” to open the phone gallery.</div><input id="f-photo" value="${esc(item.photo||'')}" placeholder="Photo URL (optional)" style="margin-top:8px"></div></div></div><div class="field"><label>Verification Badge</label><select id="f-verified"><option value="false" ${!item.verified?'selected':''}>Not Verified</option><option value="true" ${item.verified?'selected':''}>Verified ✓ — Give Badge</option></select></div><div class="actions"><button class="btn light" onclick="document.getElementById('modal').remove()">Cancel</button><button class="btn primary" onclick="submitMemberForm()">Save</button></div></div></div>`);window._memberForm={item,done}}
function previewMemberPhoto(input){const file=input.files&&input.files[0];if(!file)return;const img=document.getElementById('photo-preview');if(img){if(img._previewUrl)URL.revokeObjectURL(img._previewUrl);img._previewUrl=URL.createObjectURL(file);img.src=img._previewUrl}}
async function submitMemberForm(){
  const {item,done}=window._memberForm;
  item.name=document.getElementById('f-name').value.trim();
  item.role=document.getElementById('f-role').value.trim();
  item.bio=document.getElementById('f-bio').value.trim();
  item.skills=document.getElementById('f-skills').value.split(',').map(x=>x.trim()).filter(Boolean);
  item.verified=document.getElementById('f-verified').value==='true';
  const fileInput=document.getElementById('f-photo-file');
  const file=fileInput?.files?.[0]||null;
  try{
    if(file){
      if(!session?.user?.id)throw Error('Admin session expired');
      if(!file.type||!file.type.startsWith('image/'))throw Error('Please choose an image file');
      if(file.size>8*1024*1024)throw Error('Photo is too large (maximum 8 MB)');

      // Keep the selected image immediately in the device cache. This means the
      // new photo remains available even if the app goes offline after saving.
      if(item.id)await photoPut(item.id,'',file);

      const safe=file.name.toLowerCase().replace(/[^a-z0-9._-]/g,'-')||'profile.jpg';
      const memberId=item.id||crypto.randomUUID();
      const path=memberId+'/'+Date.now()+'-'+safe;
      const base=cfg.url.replace(/\/$/,'');
      const r=await fetch(base+'/storage/v1/object/member-photos/'+path,{
        method:'POST',
        headers:headers({'x-upsert':'true','Content-Type':file.type,'Cache-Control':'3600'}),
        body:file
      });
      if(!r.ok){
        const detail=await r.text().catch(()=> '');
        throw Error(detail||('Photo upload failed (HTTP '+r.status+')'));
      }
      item.photo=base+'/storage/v1/object/public/member-photos/'+path+'?v='+Date.now();

      // Replace the temporary cache entry with the final public URL.
      if(item.id)await photoPut(item.id,item.photo,file);
    }else{
      item.photo=document.getElementById('f-photo').value.trim();
    }

    document.getElementById('modal').remove();
    await done(item);
  }catch(e){
    toast('Photo/save failed: '+friendly(e));
  }
}
async function removeItem(key,id){if(!confirm('Remove this item?'))return;try{await dbDelete('content_items','id=eq.'+encodeURIComponent(id));await sync();render()}catch(e){toast(friendly(e))}}
async function editCollection(key,id){const existing=id?state[key].find(x=>String(x.id)===String(id)):null;const item=existing?{...existing}:{id:null,title:'',description:'',tags:[],image:''};const kind=key==='projects'?'project':key==='skills'?'skill':'gallery';openContentForm('Edit '+key.slice(0,-1),item,kind,async x=>{try{const row={kind,title:x.title,description:x.description||'',tags:x.tags||[],image_url:x.image||null};if(id)await dbPatch('content_items','id=eq.'+encodeURIComponent(id),row);else await dbInsert('content_items',row);await sync();render()}catch(e){toast(friendly(e))}})}
function openContentForm(title,item,kind,done){document.body.insertAdjacentHTML('beforeend',`<div class="modal" id="modal"><div class="sheet"><h2>${title}</h2><div class="field"><label>Title</label><input id="f-title" value="${esc(item.title)}"></div><div class="field"><label>Description</label><textarea id="f-description">${esc(item.description||'')}</textarea></div><div class="field"><label>Tags</label><input id="f-tags" value="${esc((item.tags||[]).join(', '))}"></div>${kind==='gallery'?`<div class="field"><label>Image URL</label><input id="f-image" value="${esc(item.image||'')}"></div>`:''}<div class="actions"><button class="btn light" onclick="document.getElementById('modal').remove()">Cancel</button><button class="btn primary" onclick="submitContentForm()">Save</button></div></div></div>`);window._contentForm={item,done,kind}}
async function submitContentForm(){const {item,done}=window._contentForm;item.title=document.getElementById('f-title').value.trim();item.description=document.getElementById('f-description').value.trim();item.tags=document.getElementById('f-tags').value.split(',').map(x=>x.trim()).filter(Boolean);if(document.getElementById('f-image'))item.image=document.getElementById('f-image').value.trim();document.getElementById('modal').remove();await done(item)}
async function saveSettings(){const s={...state.settings};for(const k of Object.keys(s)){const el=document.getElementById('set-'+k);if(el)s[k]=el.value.trim()}try{await dbPatch('site_settings','id=eq.1',{settings:s});await sync();render();toast('Settings saved online')}catch(e){toast(friendly(e))}}
async function go(r){route=r;render();if(r==='chat'){if(session)loadChat();if(chatTimer)clearInterval(chatTimer);if(session)chatTimer=setInterval(loadChat,8000)}else if(chatTimer){clearInterval(chatTimer);chatTimer=null}if(configured()&&r!=='admin')sync()}
function toast(msg){let t=document.getElementById('toast');if(!t){t=document.createElement('div');t.id='toast';Object.assign(t.style,{position:'fixed',left:'16px',right:'16px',bottom:'82px',zIndex:50,background:'#111827',color:'#fff',padding:'12px 14px',borderRadius:'12px',textAlign:'center'});document.body.appendChild(t)}t.textContent=msg;setTimeout(()=>t.remove(),2800)}
async function init(){render();if(configured()){if(session){try{adminSession=await isAdmin();}catch{adminSession=false}}await sync();render()}}
init();
