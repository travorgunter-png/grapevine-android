GRAPEVINE Android V12 — verified badge rebuild

Launcher icon: supplied GRAPEVINE emblem artwork.
Verification badge: inline SVG blue circular zigzag/seal with a white checkmark. It is rendered directly in the HTML/DOM, not loaded as an image, so it cannot become a broken-image placeholder.
The badge appears beside a member name whenever verified is true and is controlled online by the admin dashboard.
The first offline demo member is marked verified so the badge is visible immediately for testing. Supabase data controls the real state after synchronization.
Startup uses the V9 local HTTPS asset-origin approach.
versionCode 12 / versionName 12.0.


V13 offline photo fix: member profile photos are cached persistently in IndexedDB by member id. The app reuses the last saved photo when offline and refreshes it from Supabase when online. This avoids relying on the service worker to intercept cross-origin Supabase storage images.
