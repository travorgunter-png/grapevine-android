GRAPEVINE Android V15 — profile photo display fix

This build keeps the V14 offline profile-photo cache and fixes the rendering lifecycle: profile-photo hydration now runs after every render, so cached or freshly uploaded member photos are applied to the All Members and Admin Members lists instead of leaving the fallback image visible.

Profile photo behavior:
- Selecting a photo previews it immediately.
- Online admin saves upload the image to Supabase Storage and update profiles.photo_url.
- The image bytes are cached persistently in IndexedDB by member id.
- All Members and Admin Members hydrate their images after every render/filter/sync.
- Offline mode uses the last cached image.
- Returning online refreshes the cached image when the stored photo URL changes.

Verification badge and launcher icon are unchanged.
